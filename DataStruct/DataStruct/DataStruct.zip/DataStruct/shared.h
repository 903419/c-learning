#ifndef _MAIN_H_
#define _MAIN_H_

#include <vld.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include <malloc.h>
#pragma warning(disable:4996)

#define ElementType int

int cmp(const void *a, const void *b)
{
	return *(ElementType *)a - *(ElementType *)b;
}

void Swap(const void *a, const void *b)
{
	*(ElementType *)a ^= *(ElementType *)b;
	*(ElementType *)b ^= *(ElementType *)a;
	*(ElementType *)a ^= *(ElementType *)b;
}


//void DCListPushFront(DCList *phead, ElementType x)
//{
//	assert(phead != NULL);
//	DCListNode *s = _BuyNode(x);
//	DCListNode *p = *phead;
//	s->prev = p;
//	s->next = p->next;
//	p->next->prev = s;
//	p->next = s;
//}
//void DCListPopBack(DCList *phead)
//{
//	assert(phead != NULL);
//	if ((*phead)->next == *phead)
//	{
//		return;
//	}
//	DCListNode *p = (*phead)->prev;
//	p->prev->next = *phead;
//	(*phead)->prev = p->prev;
//	free(p);
//}
//
//void DCListClear(DCList *phead)
//{
//	assert(phead != NULL);
//	if ((*phead)->next == *phead)
//	{
//		return;
//	}
//	DCListNode *p = (*phead)->next;
//	DCListNode *tmp = NULL;
//	while (p != *phead)
//	{
//		tmp = p;
//		p = p->next;
//		free(tmp);
//	}
//	(*phead)->next = (*phead)->prev = *phead;
//}
//
//void DCListEraseByval(DCList *phead, ElementType x)
//{
//	assert(phead != NULL);
//	DCListNode *p = (*phead)->next;
//	while (p != *phead && p->data != x)
//	{
//		p = p->next;
//	}
//	if (p!=*phead && p->data == x)
//	{
//		p->prev->next = p->next;
//		p->next->prev = p->prev;
//		free(p);
//		p = NULL;
//	}
//}
//
//void DCListSort(DCList *phead)
//{
//	assert(phead != NULL);
//	if (DCListLength(phead) <= 1)
//	{
//		return;
//	}
//	DCListNode *p = (*phead)->next,*tmp= (*phead)->next,*s=NULL;
//	DCListNode *q = p->next;
//	p->next->prev = NULL;
//	p->next = NULL;
//	while (q != *phead)
//	{
//		p = q;
//		q = q->next;
//		while (tmp!=NULL && p->data > tmp->data)
//		{
//			s = tmp;
//			tmp = tmp->next;
//		}
//		if (s == NULL)
//		{
//			tmp->next = p;
//			p->prev = tmp;
//		}
//		else
//		{
//			p->next = 
//		}
//	}
//}


//void LinkQueueDe(LinkQueue *pq)
//{
//	assert(pq != NULL);
//	LinkQueueNode *p = pq->head;
//	pq->head = p->link;
//	free(p);
//}


typedef struct SeqQueue
{
	ElementType *base;
	int capacity;
	int front;
	int rear;
}SeqQueue;

void SeqQueueInit(SeqQueue *psq)
{
	assert(psq != NULL);
	psq->capacity = 8;
	psq->base = (ElementType *)malloc(sizeof(ElementType));
	psq->front = 0;
	psq->rear = 0;
}

void SeqQueueEn(SeqQueue *psq, ElementType x)
{
	assert(psq != NULL);
	if (psq->front == psq->rear)
	{
		psq->base[psq->front] = x;
		psq->rear++;
	}
	else
	{
		psq->base[psq->rear] = x;
		psq->rear++;
	}
}

void SeqQueueDe(SeqQueue *psq)
{
	assert(psq != NULL);
	if (psq->front == psq->rear)
	{
		return;
	}
	else
	{
		psq->front++;
	}
}

ElementType SeqQueueFront(SeqQueue *psq)
{
	assert(psq != NULL);
	if (psq->front != psq->rear)
	{
		return psq->base[psq->front];
	}
	return 0;
}

int SeqQueueSize(SeqQueue *psq)
{
	assert(psq != NULL);
	return psq->rear;
}
bool SeqQueueEmpty(SeqQueue *psq)
{
	assert(psq != NULL);
	return psq->front == psq->rear;
}

void SeqQueueShow(SeqQueue *psq)
{
	assert(psq != NULL);
	int tmp = psq->front;
	while (tmp != psq->rear)
	{
		printf("%d ", psq->base[tmp]);
		tmp++;
	}
	printf("\n");
}

void SeqQueueDestroy(SeqQueue *psq)
{
	free(psq->base);
	psq->capacity = psq->front = psq->rear = 0;
}



#endif // !_MAIN_H_
